package edu.cs4730.flutterfirebasedemo;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
