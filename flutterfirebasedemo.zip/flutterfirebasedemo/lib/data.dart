import 'package:cloud_firestore/cloud_firestore.dart';

/*
class People {
  final String id;
  final String first;
  final String middle;
  final String last;
  final String born;
  final DocumentReference reference;

*/
/*
  //a base constructor, I think
  People._() :
    id = null,
    first = "",
    middle = "",
    last = "",
    born = "1000",
    reference = null;
*//*


  People.fromSnapShot(DocumentSnapshot snapshot)
        first = snapshot.data()!['first'],
        middle = snapshot.data()!['middle'],
        last = snapshot.data()!['last'],
        born = snapshot.data()!['born'],
}
*/
